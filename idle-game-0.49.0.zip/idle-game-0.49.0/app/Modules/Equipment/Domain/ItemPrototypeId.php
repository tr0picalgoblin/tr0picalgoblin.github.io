<?php declare(strict_types=1);


namespace App\Modules\Equipment\Domain;


use App\Modules\Generic\Domain\BaseId;

class ItemPrototypeId extends BaseId
{
}
