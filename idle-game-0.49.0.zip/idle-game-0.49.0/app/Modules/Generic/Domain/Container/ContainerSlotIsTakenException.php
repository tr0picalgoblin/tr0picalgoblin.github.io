<?php

namespace App\Modules\Generic\Domain\Container;

use RuntimeException;

class ContainerSlotIsTakenException extends RuntimeException
{
}
