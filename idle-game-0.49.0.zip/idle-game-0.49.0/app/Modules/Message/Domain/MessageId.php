<?php declare(strict_types=1);


namespace App\Modules\Message\Domain;


use App\Modules\Generic\Domain\BaseId;

class MessageId extends BaseId
{
}
