<?php declare(strict_types=1);


namespace App\Modules\Trade\Domain;


use App\Modules\Generic\Domain\BaseId;

class StoreId extends BaseId
{
}
