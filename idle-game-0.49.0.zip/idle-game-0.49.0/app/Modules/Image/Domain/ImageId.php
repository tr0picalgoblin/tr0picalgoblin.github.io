<?php declare(strict_types=1);


namespace App\Modules\Image\Domain;


use App\Modules\Generic\Domain\BaseId;

class ImageId extends BaseId
{
}
