<div class="message-list-container row">
    <div class="col-md-12 text-center">
        No battles.
    </div>
</div>