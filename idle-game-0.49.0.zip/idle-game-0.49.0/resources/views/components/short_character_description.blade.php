{{ $character->name }}
({{ $character->getRaceName() }})
