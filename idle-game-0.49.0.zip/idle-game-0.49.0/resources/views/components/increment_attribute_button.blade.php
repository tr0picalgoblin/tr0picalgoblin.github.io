@if($hasFreePoints)
<td class="circle">
    <button type="submit" class="btn btn-sm btn-success btn-block increment_attribute" id="{{$slot}}">+1</button>
</td>
@endif