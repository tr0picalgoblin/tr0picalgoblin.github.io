@extends("base")

@section("head")
    <title>Be right back.</title>

    @parent
@stop

@section("body")
    <div class="content">
        <div class="title">Be right back.</div>
    </div>
@stop
